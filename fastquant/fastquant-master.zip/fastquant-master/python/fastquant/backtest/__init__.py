# Modules available for fastquant.backtest.*

from fastquant.backtest.backtest import backtest
from fastquant.backtest.backtest import STRATEGY_MAPPING
