module.exports = {
  someSidebar: {
    Docs: ['getting_started'],
    Reference: ['backtest', 'get_stock_data', 'get_crypto_data', 'walk_forward_data_split'],
  },
};
